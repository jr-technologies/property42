<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="login-registarHolder">
        <ul class="tabset">
            <li class="active"><a href="<?php echo e(url('/login')); ?>">login</a></li>
            <li><a href="<?php echo e(url('/register')); ?>">become a free member</a></li>
        </ul>
        <div class="tab-content">
            <div id="tab1">
                <?php
                if(\Session::has('validationErrors')){
                    $validationErrors = \Session::get('validationErrors');
                }
                ?>
                <?php if(\Session::has('errors')): ?>
                    <span class="global-error">
                        <?php foreach(\Session::get('errors') as $error): ?>
                            <?php echo e($error); ?><br>
                        <?php endforeach; ?>
                    </span>
                <?php endif; ?>

                    <?php if(\Session::has('success')): ?> <span class="global-successMessage"><?php echo e(\Session::get('success')); ?> !</span> <?php endif; ?>
                    <form class="login-form" action="<?php echo e(route('login')); ?>" method="post">
                        <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('email')): ?> error <?php endif; ?>">
                            <label class="icon-envelope" for="email"></label>
                            <input name="email" type="email" value="<?php echo e(old('email')); ?>" placeholder="Enter Your Email Address" id="email" required>
                            <span class="border"></span>
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('email')): ?> <?php echo e($validationErrors->first('email')); ?> <?php endif; ?></span>
                        </div>
                        <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('password')): ?> error <?php endif; ?>">
                            <label class="icon-key" for="pass"></label>
                            <input name="password" type="password" value="<?php echo e(old('password')); ?>" placeholder="Enter Your Password" id="pass" required>
                            <span class="border"></span>
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('password')): ?> <?php echo e($validationErrors->first('password')); ?> <?php endif; ?></span>
                            <a href=<?php echo e(URL::to('forget-password')); ?> class="forgot-pass"><span class="icon-notification"></span> Forgot Password</a>
                        </div>
                        <button type="submit">Login <span class="icon-login"></span></button>
                    </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>