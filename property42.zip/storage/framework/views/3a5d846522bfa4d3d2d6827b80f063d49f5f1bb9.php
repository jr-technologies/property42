
<?php $__env->startSection('content'); ?>
    <div id="content">

        <div class="container">
            <div class="page-holder">
                <div class="public-propertyListing">
                    <div class="holder">
                        <span class="searchResult-counter">Showing <b>1</b> to <b><?php echo e($response['data']['propertiesCount']); ?></b> of
                            <b><?php echo e($response['data']['totalProperties']); ?></b> properties</span>
                        <ul class="sortBy">
                            <li>Sorty By</li>
                            <li>
                                <select>
                                    <option>Default Order</option>
                                    <option>Price low to high</option>
                                    <option>Price high to low</option>
                                    <option>Beds low to high</option>
                                    <option>Bed high to low</option>
                                    <option>Area low to high</option>
                                    <option>Area high to low</option>
                                    <option>Date new to old</option>
                                    <option>Date old to new</option>
                                    <option>Verified only</option>
                                    <option>Hot only</option>
                                    <option>With videos</option>
                                    <option>With photos</option>
                                </select>
                            </li>
                        </ul>
                        <div class="layout">
                            <a href="#SearchPublic-Property" class="mySearch lightbox">My Search<span class="icon-search"></span></a>
                        </div>
                    </div>

                    <section class="property-posts">
                        <?php foreach($response['data']['properties'] as $property): ?>
                            <article class="post">
                                <?php
                                $image = url('/')."/assets/imgs/no.png";
                                foreach($property->documents as $document)
                                {
                                    if($document->type == 'image' && $document->main == true)
                                    {
                                        $image = url('/').'/temp/'.$document->path;
                                    }
                                }
                                ?>
                                <div class="img-holder"><a href="property?propertyId=<?php echo e($property->id); ?>"><img src="<?php echo e($image); ?>" width="600" height="450" alt="image description"></a></div>
                                <div class="caption">
                                    <strong class="post-heading"><a href="property?propertyId=<?php echo e($property->id); ?>"><span class="landUnit"><?php echo e(''.$property->land->area.' '.$property->land->unit->name .' '); ?></span> <?php echo e($property->type->subType->name.'
                        '.$property->purpose->name.' in '.$property->location->block->name.' Block'.
                        ' '.$property->location->society->name); ?></a><span
                                                class="price">Rs <?php echo e(App\Libs\Helpers\PriceHelper::numberToRupees($property->price)); ?></span>
                                        <span class="subTitle"><?php echo e('('.str_limit($property->title,25).')'); ?></span>
                                    </strong>
                                    <address><?php echo e(str_limit($property->description,150)); ?>.</address>
                                    <ul class="property-details">
                                        <?php foreach($property->features as $feature): ?>
                                            <?php foreach($feature as $featureSection): ?>
                                                <?php if($featureSection->priority ==1): ?>
                                                    <li><?php echo e($featureSection->value); ?> <?php echo e($featureSection->name); ?></li>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        <?php endforeach; ?>
                                    </ul>
                                    <div class="holder">
                                        <ul class="quick-links">
                                            <li><a href="property?propertyId=<?php echo e($property->id); ?>"><span class="icon-pencil"></span>More Details</a></li>

                                        </ul>

                                        <?php
                                        $image = url('/') . "/assets/imgs/no.png";
                                        if ($property->owner->agency != null) {
                                            if ($property->owner->agency->logo != null) {
                                                $image = url('/') . '/temp/' . $property->owner->agency->logo;
                                            }
                                        }
                                        ?>
                                        <div class="state-logo"><a href="<?php echo e(URL::to('agent?agent_id='.$property->owner->id)); ?>">
                                                <img src="<?php echo e($image); ?>" width="300" height="300" alt="Property42.pk">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </section>
                    <?php
                    $for_previous_link = $_GET;
                    $pageValue = (isset($for_previous_link['page']))?$for_previous_link['page']:1;
                    ($pageValue ==1)?$for_previous_link['page'] = $pageValue:$for_previous_link['page'] = $pageValue-1;
                    $convertPreviousToQueryString  = http_build_query($for_previous_link);
                    $previousResult = URL('/search').'?'.$convertPreviousToQueryString;
                    ?>
                    <?php
                    $totalPaginationValue = intval(ceil($response['data']['totalProperties'] / config('constants.Pagination')));
                    $for_next_link = $_GET;
                    $pageValue = (isset($for_next_link['page']))?$for_next_link['page']:1;
                    ($pageValue == $totalPaginationValue)?$for_next_link['page'] = $pageValue:$for_next_link['page'] = $pageValue+1;
                    $convertToQueryString  = http_build_query($for_next_link);
                    $nextResult = URL('/search').'?'.$convertToQueryString;
                    ?>
                    <ul class="pager">
                        <?php if($totalPaginationValue !=0): ?>
                        <li><a href="<?php echo e($previousResult); ?>" class="previous"><span class="icon-chevron-thin-left"></span></a></li>
                        <?php endif; ?>
                        <?php
                        $paginationValue = intval(ceil($response['data']['totalProperties'] / config('constants.Pagination')));
                        $query_str_to_array = $_GET;
                        $current_page = (isset($query_str_to_array['page']))?$query_str_to_array['page']:1;
                        for($i = (($current_page-3 > 0)?$current_page-3:1); $i <= (($current_page + 3 <= $paginationValue)?$current_page+3:$paginationValue);$i++){
                        $query_str_to_array['page'] = $i;
                        $queryString  = http_build_query($query_str_to_array);
                        $result = URL('/search').'?'.$queryString;
                        ?>
                        <li <?php if($current_page == $i): ?>class="active" <?php endif; ?>><a href="<?php echo e($result); ?>"><?php echo e($i); ?></a></li>
                        <?php }?>
                            <?php if($totalPaginationValue !=0): ?>
                            <li><a href="<?php echo e($nextResult); ?>" class="next"><span class="icon-chevron-thin-right"></span></a></li>
                          <?php endif; ?>
                    </ul>

                    <div class="lightbox" id="SearchPublic-Property">
                        <div class="mySearch-Form">
                            <?php echo e(Form::open(array('url' => 'search','method' => 'GET'))); ?>

                            <ul class="propertyPurpose">
                                <li>
                                    <label for="buy-1">
                                        <input type="radio" name="purpose_id" value="1" id="buy-1" <?php if($response['data']['oldValues']['purposeId'] == 1): ?> checked <?php endif; ?>>
                                        <span class="fake-label">Buy</span>
                                    </label>
                                </li>
                                <li>
                                    <label for="rent-1">
                                        <input type="radio" name="purpose_id" id="rent-1" value="2" <?php if($response['data']['oldValues']['purposeId'] == 2): ?> checked <?php endif; ?>>
                                        <span class="fake-label">Rent</span>
                                    </label>
                                </li>
                            </ul>
                            <ul class="propertyType">
                                <?php foreach($response['data']['propertyTypes'] as $propertyType): ?>
                                    <li>
                                        <label for=<?php echo e($propertyType->name.$propertyType->id); ?>>
                                            <input type="radio" id=<?php echo e($propertyType->name.$propertyType->id); ?>

                                                    class="property_type"  name="property_type_id" value="<?php echo e($propertyType->id); ?>"
                                                   <?php if($response['data']['oldValues']['propertyTypeId'] == $propertyType->id): ?>checked <?php endif; ?>>
                                            <span class="fake-label"><?php echo e($propertyType->name); ?></span>
                                        </label>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                            <ul class="fields">
                                <li>
                                    <label>Select Sub Type:</label>
                                    <span class="fake-select">
                                    <span class="load">
                                    <select name="sub_type_id" id="property_sub_types" old_sub_type="<?php echo e($response['data']['oldValues']['subTypeId']); ?>">
                                        <option  value="">All Property SubType</option>
                                        <?php foreach($response['data']['propertySubtypes'] as $propertySubType): ?>
                                            <option value="<?php echo e($propertySubType->id); ?>"><?php echo e($propertySubType->name); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </span>
                                        </span>
                                </li>
                                <li>
                                    <label>Select Society:</label>
                                    <span class="fake-select">
                                      <span class="load">
                                    <select name="society_id" id="society" class="js-example-basic-single">
                                        <option  value="">All Societies</option>
                                        <?php foreach($response['data']['societies'] as $society): ?>
                                            <option value="<?php echo e($society->id); ?>" <?php if($response['data']['oldValues']['societyId'] == $society->id): ?> selected <?php endif; ?>><?php echo e($society->name); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </span>
                               </span>
                                </li>
                                <li>
                                    <label>Select Block:</label>
                                  <span class="fake-select">
                                      <span class="load">
                                        <select class="js-example-basic-single" name="block_id" id="blocks" old_block="<?php echo e($response['data']['oldValues']['blockId']); ?>">
                                            <option selected value="">Any</option>
                                        </select>
                                      </span>
                                 </span>
                                </li>
                                <li class="bedrooms">
                                    <label>Select Bedrooms:</label>
                                    <span class="fake-select">
                                    <span class="load">
                                    <select name="property_features[28]" id="bedrooms-select">
                                        <option value="">Any</option>
                                        <option value=1 <?php if($response['data']['oldValues']['propertyFeatures'][28] == 1): ?> selected <?php endif; ?>>1</option>
                                        <option value=2 <?php if($response['data']['oldValues']['propertyFeatures'][28] == 2): ?> selected <?php endif; ?>>2</option>
                                        <option value=3 <?php if($response['data']['oldValues']['propertyFeatures'][28] == 3): ?> selected <?php endif; ?>>3</option>
                                        <option value=4 <?php if($response['data']['oldValues']['propertyFeatures'][28] == 4): ?> selected <?php endif; ?>>4</option>
                                        <option value=5 <?php if($response['data']['oldValues']['propertyFeatures'][28] == 5): ?> selected <?php endif; ?>>5</option>
                                        <option value=6 <?php if($response['data']['oldValues']['propertyFeatures'][28] == 6): ?> selected <?php endif; ?>>6</option>
                                        <option value=7 <?php if($response['data']['oldValues']['propertyFeatures'][28] == 7): ?> selected <?php endif; ?>>7</option>
                                        <option value=8 <?php if($response['data']['oldValues']['propertyFeatures'][28] == 8): ?> selected <?php endif; ?>>8</option>
                                        <option value=9 <?php if($response['data']['oldValues']['propertyFeatures'][28] == 9): ?> selected <?php endif; ?>>9</option>
                                        <option value=10 <?php if($response['data']['oldValues']['propertyFeatures'][28] == 10): ?> selected <?php endif; ?>>10</option>
                                    </select>
                                        </span>
                                        </span>
                                </li>
                                <li>
                                    <label>Price Range (Rs):</label>
                                    <div class="input-holder priceArea"><input type="number" placeholder="From" name="price_from" value="<?php echo e($response['data']['oldValues']['priceFrom']); ?>" class="PriceField priceInputFrom"><span class="price-Range detailedPriceFrom">Please enter the price</span></div>
                                    <div class="input-holder priceArea"><input type="number" placeholder="To" name="price_to"value="<?php echo e($response['data']['oldValues']['priceTo']); ?>" class="PriceField priceInputTo"><span class="price-Range detailedPriceTo">Please enter the price</span></div>
                                </li>
                                <li>

                                        <label>Land Unit</label>
                                        <div class="input-holder add">
                                        <select name="land_unit_id" name="land_unit_id">
                                            <?php foreach($response['data']['landUnits'] as $landUnit): ?>
                                                <option value="<?php echo e($landUnit->id); ?>" <?php if($response['data']['oldValues']['landUnitId'] == $landUnit->id): ?> selected <?php endif; ?>><?php echo e($landUnit->name); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        </div>

                                    <div class="input-holder add"><input type="number" placeholder="From" name="land_area_from" value="<?php echo e($response['data']['oldValues']['landAreaFrom']); ?>"></div>
                                    <div class="input-holder add"><input type="number" placeholder="To" name="land_area_to" value="<?php echo e($response['data']['oldValues']['landAreaTo']); ?>"></div>
                                </li>
                            </ul>
                            <button type="submit"><span class="icon-search"></span>Search my property</button>
                            <?php echo e(Form::close()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <script>
        $(document).on('loaded','#property_sub_types', function () {
            var subTypeId = parseInt($('#property_sub_types').attr('old_sub_type'));
            if(!isNaN(subTypeId)){
                $("#property_sub_types").val(subTypeId).change();
            }
        });
        $(document).on('loaded','#blocks', function () {
            var subTypeId = parseInt($('#blocks').attr('old_block'));
            if(!isNaN(subTypeId)){
                $("#blocks").val(subTypeId).change();
            }
        });

        $(document).ready(function(){
            $('.property_type').trigger('change');
            $('#society').trigger('change');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>