<h1>Property42</h1>
<b><?php echo e($user['userId']); ?></b><br />
<b><?php echo e($user['email']); ?></b><br />
<b><?php echo e($user['message']); ?></b><br />
