<?php $__env->startSection('content'); ?>
<main id="main" role="main">
    <div class="container">
        <div class="forgot-passwordHolder">

                <?php
                if(\Session::has('validationErrors')){
                    $validationErrors = \Session::get('validationErrors');
                }
                ?>
             <div class="forgot-password">
                 <?php if(\Session::has('message')): ?>
                     <span class="global-successMessage"><?php echo e(\Session::get('message')); ?></span>
                 <?php endif; ?>
               <?php echo e(Form::open(array('url' => 'get-new-password','method' => 'POST' ,'class'=>'forgot-form'))); ?>

                    <strong class="forgot-heading">Let's get you into your account.</strong>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('email')): ?> error <?php endif; ?>">
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('email')): ?> <?php echo e($validationErrors->first('email')); ?> <?php endif; ?></span>
                        <input type="email" name="email" placeholder="Enter Your Email Address" id="email">
                        <span class="border"></span>
                        <label for="email" class="icon-envelope"></label>
                    </div>
                    <button type="submit">Send Password</button>
                    <a href="<?php echo e(url('/login')); ?>" class="btn-log">Click for Login</a>
               <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>