<?php $__env->startSection('content'); ?>

    <div class="registerNow container">
        <?php
            if(\Session::has('validationErrors')){
                $validationErrors = \Session::get('validationErrors');
            }
        ?>
        <form class="registration-form" method="post" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
            <h1>Register <span>Now</span></h1>
            <div class="layout">
                <div class="layout-holder">
                    <label for="f-name">First Name</label>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('fName')): ?> error <?php endif; ?>">
                        <input type="text" placeholder="Enter Your First Name" name="fName" id="fName" value="<?php echo e(old('fName')); ?>" required>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('fName')): ?> <?php echo e($validationErrors->first('fName')); ?> <?php endif; ?></span>
                    </div>
                </div>
                <div class="layout-holder">
                    <label for="l-name">Last Name</label>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('lName')): ?> error <?php endif; ?>">
                        <input type="text" placeholder="Enter Your Last Name" name="lName" value="<?php echo e(old('lName')); ?>" id="lName" required>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('lName')): ?> <?php echo e($validationErrors->first('lName')); ?> <?php endif; ?></span>
                    </div>
                </div>
                <div class="layout-holder">
                    <label for="email">Email</label>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('email')): ?> error <?php endif; ?>">
                        <input type="email" placeholder="Enter Your Email Address"  id="email1" value="<?php echo e(old('email')); ?>" name="email" required>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('email')): ?> <?php echo e($validationErrors->first('email')); ?> <?php endif; ?></span>
                    </div>
                </div>
            </div>
            <div class="layout">
                <div class="layout-holder">
                    <label for="pass">Password</label>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('password')): ?> error <?php endif; ?>">
                        <input type="password" placeholder="Enter Your Password" id="pass1"  name="password" required>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('password')): ?> <?php echo e($validationErrors->first('password')); ?> <?php endif; ?></span>
                    </div>
                </div>
                <div class="layout-holder">
                    <label for="re-pass">Re-Enter Password</label>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('passwordAgain')): ?> error <?php endif; ?>">
                        <input type="password"  placeholder="Confirm Password" name="passwordAgain" id="cpass" required>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('passwordAgain')): ?> <?php echo e($validationErrors->first('passwordAgain')); ?> <?php endif; ?></span>
                    </div>
                </div>
            </div>
            <strong class="registerNow-heading"><span>Contact Information</span></strong>
            <div class="layout two">
                <div class="layout-holder">
                    <label for="address">Address</label>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('address')): ?> error <?php endif; ?>">
                        <input type="text" placeholder="Enter Your Address" value="<?php echo e(old('address')); ?>" name="address" id="address" >
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('address')): ?> <?php echo e($validationErrors->first('address')); ?> <?php endif; ?></span>
                    </div>
                </div>
                <div class="layout-holder">
                    <label for="m-number">Mobile Number</label>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('mobile')): ?> error <?php endif; ?>">
                        <input type="tel" placeholder="Enter Your Cell / Mobile Number" value="<?php echo e(old('mobile')); ?>" name="mobile" id="cell" required>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('mobile')): ?> <?php echo e($validationErrors->first('mobile')); ?> <?php endif; ?></span>
                    </div>
                </div>
            </div>
            <div class="layout two">
                <div class="layout-holder phone-num">
                    <label for="p-number">Phone Number</label>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('phone')): ?> error <?php endif; ?>">
                        <input type="tel" placeholder="Enter Your Phone Number" name="phone" value="<?php echo e(old('phone')); ?>" id="p-number" >
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('phone')): ?> <?php echo e($validationErrors->first('phone')); ?> <?php endif; ?></span>
                    </div>
                </div>
                <div class="layout-holder otherRole">
                    <label for="address">Other Roles</label>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('userRoles')): ?> error <?php endif; ?>">
                        <a class="role-opener">0 Selected</a>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('userRoles')): ?> <?php echo e($validationErrors->first('userRoles')); ?> <?php endif; ?></span>
                    </div>
                </div>
            </div>
            <ul class="role-listing">
                <?php foreach($response['roles'] as $role): ?>
                    <li>
                        <label for="role_<?php echo e($role->id); ?>" class="customCheckbox">
                            <input type="checkbox" id="role_<?php echo e($role->id); ?>" class="userRole-checkbox <?php if($role->id == 3): ?> agent-brokerCheckbox <?php endif; ?>;" name="userRoles[]" value="<?php echo e($role->id); ?>" <?php if(in_array($role->id,(old('userRoles') !=null)?old('userRoles'):[])): ?> checked <?php endif; ?>>
                            <span class="fake-checkbox"></span>
                            <span class="fake-label"><?php echo e($role->name); ?></span>
                        </label>
                    </li>
                <?php endforeach; ?>
            </ul>
            <strong class="registerNow-heading smaller">
            <span>
                Are you an Agent ? <b>No</b>
                <label for="agentCheck-field" class="agent-check">
                    <input type="checkbox" class="hidden-checkfield agent-brokerCheckbox" name="agent" <?php if(old('agent') !=""): ?>checked <?php endif; ?>  id="agentCheck-field">
                    <span class="fake-checkbox">
                        <span class="fake-button"></span>
                    </span>
                </label>
                <b>Yes</b>
            </span>
            </strong>
            <div class="agent-information">
                <strong class="registerNow-heading">Agent Information</strong>
                <div class="layout two first-small">
                    <div class="layout-holder">
                        <div class="company-logo">
                            <input type="file" name="companyLogo"  onchange="companyLogoUploader(this , '.company-profileP')" id="c-logo">
                            <span class="name-tag">Add Company Logo</span>
                            <div class="logo-holder">
                                <label for="c-logo"><span class="icon-plus-square"></span></label>
                                <div class="picture-holder">
                                    <img src="" class="company-profileP" alt="Company logo">
                                    <a class="company-logo-delete"><span class="icon-cross"></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="layout-holder">
                        <div class="full-width">
                            <label for="agencyName">Agency Name</label>
                            <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('agencyName')): ?> error <?php endif; ?>">
                                <input type="text" placeholder="Enter An Agency Name" id="agency-name" name="agencyName" value="<?php echo e(old('agencyName')); ?>" >
                                <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('agencyName')): ?> <?php echo e($validationErrors->first('agencyName')); ?> <?php endif; ?></span>
                            </div>
                        </div>
                        <div class="full-width">
                            <label for="D-services">Agency Description</label>
                            <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('agencyDescription')): ?> error <?php endif; ?>">
                                <textarea id="D-services" name="agencyDescription" placeholder="Description of Services"><?php echo e(old('agencyDescription')); ?></textarea>
                                <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('agencyDescription')): ?> <?php echo e($validationErrors->first('agencyDescription')); ?> <?php endif; ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="layout two first-small">
                    <div class="layout-holder">
                        <label for="selectSociety">Filter Societies You Deal In</label>
                        <div class="input-holder  <?php if(isset($validationErrors) && $validationErrors->has('societies')): ?> error <?php endif; ?>">
                            <input type="text" placeholder="Filter Societies You Deal In:" id="search-society" name="SelectDealSociety">
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('societies')): ?> <?php echo e($validationErrors->first('societies')); ?> <?php endif; ?></span>
                        </div>
                    </div>
                    <div class="layout-holder">
                        <ul class="packetData-list">

                        </ul>
                    </div>
                </div>
                <div class="input-holder full-width">
                    <ul class="societiesBlock-listing">
                        <?php foreach($response['societies'] as $society): ?>
                            <li>
                                <label for="society<?php echo e($society->id); ?>" class="customCheckbox">
                                    <input type="checkbox" id="society<?php echo e($society->id); ?>" class="selectSociety-checkbox" name="societies[]" value="<?php echo e($society->id); ?>"
                                           <?php if(in_array($society->id,(old('societies') !=null)?old('societies'):[])): ?> checked <?php endif; ?>>
                                    <span class="fake-checkbox"></span>
                                    <span class="fake-label"><?php echo e($society->name); ?></span>
                                </label>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <strong class="registerNow-heading">Agency Contact Details</strong>
                <div class="layout">
                    <div class="layout-holder">
                        <label for="companyPhone">Phone Number</label>
                        <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('companyPhone')): ?> error <?php endif; ?>">
                            <input type="tel" placeholder="Enter Your Phone Number" name="companyPhone" value="<?php echo e(old('phone')); ?>" id="phone" >
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('companyPhone')): ?> <?php echo e($validationErrors->first('companyPhone')); ?> <?php endif; ?></span>
                        </div>
                    </div>
                    <div class="layout-holder">
                        <label for="company-mobile">Mobile Number</label>
                        <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('companyMobile')): ?> error <?php endif; ?>">
                            <input type="tel" placeholder="Enter Company Mobile Number" name="companyMobile" value="<?php echo e(old('companyMobile')); ?>" id="company-mobile" required >
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('companyMobile')): ?> <?php echo e($validationErrors->first('companyMobile')); ?> <?php endif; ?></span>
                        </div>
                    </div>
                    <div class="layout-holder">
                        <label for="compny-email">Company E-mail</label>
                        <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('companyEmail')): ?> error <?php endif; ?>">
                            <input type="email" placeholder="Enter Company Email" name="companyEmail" value="<?php echo e(old('companyEmail')); ?>" id="compny-email" required >
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('companyEmail')): ?> <?php echo e($validationErrors->first('companyEmail')); ?> <?php endif; ?></span>
                        </div>
                    </div>
                </div>
                <div class="layout two">
                    <div class="layout-holder">
                        <label for="compny-address">Company Address</label>
                        <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('companyAddress')): ?> error <?php endif; ?>">
                            <input type="text" placeholder="Enter Company Address" name="companyAddress" value="<?php echo e(old('companyAddress')); ?>" id="compny-address"  >
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('companyAddress')): ?> <?php echo e($validationErrors->first('companyAddress')); ?> <?php endif; ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="layout two">
                <div class="layout-holder">
                    <ul class="agree-with-terms">
                        <li class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('termsConditions')): ?> error <?php endif; ?>">
                            <label for="terms-Cond" class="customCheckbox <?php if(isset($validationErrors) && $validationErrors->has('termsConditions')): ?> error <?php endif; ?>">
                                <input type="checkbox" id="terms-Cond" name="termsConditions" value="1" <?php if(old('termsConditions') !=""): ?>checked <?php endif; ?>>
                                <span class="fake-checkbox"></span>
                                <span class="fake-label">I have read and agree to Property42.pk Terms and Conditions</span>
                                <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('termsConditions')): ?> <?php echo e($validationErrors->first('termsConditions')); ?> <?php endif; ?></span>
                            </label>
                        </li>
                        <li>
                            <label for="newslatter" class="customCheckbox">
                                <input type="checkbox" id="newslatter" name="wantNotifications" <?php if(old('wantNotifications') !=""): ?>checked <?php endif; ?> >
                                <span class="fake-checkbox"></span>
                                <span class="fake-label">I want to receive notifications for promotions, newsletters and website updates.</span>
                            </label>
                        </li>
                    </ul>
                </div>
                <div class="layout-holder">
                    <input type="submit" value="SIGN ME UP">
                </div>
            </div>
        </form>
    </div>
    <script>
        $(document).ready(function(){
            $( ".hidden-checkfield" ).trigger( "change" );
            $(".selectSociety-checkbox").trigger("change");
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.v2.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>