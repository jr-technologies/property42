<?php $__env->startSection('content'); ?>
    <main id="main" role="main">
        <div class="page-holder">
            <div class="propertyDetail-page">
                <div class="container">
                    <div class="detail-holder">
                        <div class="frame">
                            <div class="property-picture-holder">
                                <h1><span> <?php echo e(''.$response['data']['property']->land->area.' '.$response['data']['property']->land->unit->name .' '); ?>

                                        <?php echo e($response['data']['property']->type->subType->name.'
                                         '.$response['data']['property']->purpose->name.' in '.$response['data']['property']->location->block->name.' Block'.
                                        ' '.$response['data']['property']->location->society->name); ?></span></h1>
                                <?php
                                $user = (new \App\Libs\Helpers\AuthHelper())->user();
                                ?>
                                <div class="propertyImage-slider carousal">
                                    <a <?php if($user ==null): ?>href="#login-to-continue" <?php endif; ?> property_id="<?php echo e($response['data']['property']->id); ?>" user_id="<?php echo e(($user !=null)?$user->id:""); ?>" key="<?php echo e(($user !=null)?$user->access_token:""); ?>" class="add-to-favorite <?php echo e(($user == null)?'lightbox':''); ?>  <?php if($response['data']['isFavourite'] != 0): ?> added <?php endif; ?>"></a>
                                    <?php /*<span class="premiumProperty text-upparcase">Premium</span>*/ ?>
                                    <div class="popup-holder">
                                        <div class="lightbox generic-lightbox" id="login-to-continue">
                                            <p>Dear user ! You are not logged in Please <a href="<?php echo e(url('/login')); ?>">Login</a></p>

                                        </div>
                                    </div>
                                    <div class="mask">
                                        <?php
                                        $images = [];
                                        foreach ($response['data']['property']->documents as $document) {
                                            if ($document->type == 'image') {
                                                $images[] = url('/') . '/temp/' . $document->path;
                                            }
                                        }
                                        if (sizeof($images) == 0) {
                                            $images[] = url('/') . "/assets/imgs/no.png";
                                        }
                                        ?>
                                        <div class="slideset">
                                            <?php foreach($images as $image): ?>
                                                <div class="slide">
                                                    <a href="<?php echo e($image); ?>" rel="lighbox" class="lightbox"><img
                                                                src="<?php echo e($image); ?>" alt="image description"></a>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                        <span id="propertyImageCurrentSlide" class="current-num"></span>
                                    </div>
                                    <a href="#" class="propertyImage-slider-btn-prev"><span
                                                class="icon-left-arrow"></span></a>
                                    <a href="#" class="propertyImage-slider-btn-next"><span
                                                class="icon-right-arrow"></span></a>

                                    <div class="propertyImage-pagination ">
                                        <div class="propertyImage-mask">
                                            <div class="propertyImage-slideset">
                                                <?php foreach($images as $image): ?>
                                                    <div class="propertyImage-slide "><a href="#"><img src="<?php echo e($image); ?>"
                                                                                                       alt="image description"></a>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                            <span class="paginationCurrent-num-1"></span>
                                        </div>
                                        <a href="#" class="propertyImage-pagination-btn-prev-1"><span
                                                    class="icon-left-arrow"></span></a>
                                        <a href="#" class="propertyImage-pagination-btn-next-1"><span
                                                    class="icon-right-arrow"></span></a>
                                    </div>
                                </div>
                                <span class="views">Views <span
                                            class="number"><?php echo e($response['data']['property']->totalViews); ?></span></span>
                                <ul class="star-rating">
                                    <li><a href="#" class="one-star">star</a></li>
                                    <li><a href="#" class="two-stars">star</a></li>
                                    <li><a href="#" class="three-stars">star</a></li>
                                    <li><a href="#" class="four-stars">star</a></li>
                                    <li><a href="#" class="five-stars">star</a></li>
                                </ul>
                            </div>
                            <?php
                            $images = url('/') . "/assets/imgs/no.png";
                            if ($response['data']['property']->owner->agency != null) {
                                if ($response['data']['property']->owner->agency->logo != null) {
                                    $images = url('/') . '/temp/' . $response['data']['property']->owner->agency->logo;
                                }
                            }
                            ?>
                            <div class="info-blockProperty">
                                <strong class="price"><span>Rs</span><?php echo e(App\Libs\Helpers\PriceHelper::numberToRupees($response['data']['property']->price)); ?>

                                </strong>
                                <?php if($response['data']['property']->owner->agency != null): ?>
                                    <div class="pictureHolder">
                                        <?php if($response['data']['user']->roles[0]->id ==3 && $response['data']['user']->trustedAgent ==1): ?>
                                        <a href="<?php echo e(URL::to('agent?agent_id='.$response['data']['property']->owner->id)); ?>">
                                            <?php endif; ?>
                                            <img src="<?php echo e($images); ?>" alt="image description"> </a></div>
                                <?php endif; ?>
                                <?php if($response['data']['property']->owner->agency !=null): ?>
                                    <?php if($response['data']['user']->roles[0]->id ==3 && $response['data']['user']->trustedAgent ==1): ?>
                                    <a href="<?php echo e(URL::to('agent?agent_id='.$response['data']['property']->owner->id)); ?>">
                                        <?php endif; ?>
                                        <span class="heading"><?php echo e($response['data']['property']->owner->agency->name); ?></span>
                                    </a>
                                <?php endif; ?>
                                <div class="layout">
                                    <div class="pull-left">
                                        <?php if(isset($response['data']['propertyOwner']->trustedAgent) && $response['data']['propertyOwner']->trustedAgent == 1): ?>
                                            <span class="trusted-agent"><span class="icon-trusted"><span
                                                            class="path1"></span><span class="path2"></span><span
                                                            class="path3"></span><span class="path4"></span><span
                                                            class="path5"></span><span class="path6"></span><span
                                                            class="path7"></span><span class="path8"></span></span>Trusted</span>
                                        <?php endif; ?>
                                        <ul class="star-rating">
                                            <li><a href="#" class="one-star">star</a></li>
                                            <li><a href="#" class="two-stars">star</a></li>
                                            <li><a href="#" class="three-stars">star</a></li>
                                            <li><a href="#" class="four-stars">star</a></li>
                                            <li><a href="#" class="five-stars">star</a></li>
                                        </ul>
                                    </div>

                                    <div class="pull-right">
                                        <ul class="quick-links">
                                            <li><a href="#callPopup" class="lightbox call-agent-btn"
                                                   data-tel="03154379760"><span class="icon-phone"></span></a></li>
                                            <li><a href="#sendEmail-popup" class="lightbox"><span
                                                            class="icon-empty-envelop"></span></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="popup-holder">
                                    <div id="callPopup" class="lightbox call-agent generic-lightbox">
                                        <span class="lighbox-heading">Phone Number</span>

                                        <p></p>
                                        <span class="information"><span class="icon-info"></span>When you call, don't forget to mention that you found this ad on Property42.pk</span>
                                    </div>
                                    <div id="sendEmail-popup" class="lightbox generic-lightbox">
                                        <span class="lighbox-heading">Send Email</span>
                                        <?php echo e(Form::open(array('url'=>'mail-to-agent','method'=>'POST','class'=>'inquiry-email-form'))); ?>

                                        <div class="field-holder">
                                            <label for="name">Name</label>

                                            <div class="input-holder"><input type="text" id="name" name="name"></div>
                                        </div>
                                        <div class="field-holder">
                                            <label for="email">Email</label>

                                            <div class="input-holder"><input type="email" id="email" name="email"
                                                                             required></div>
                                        </div>
                                        <div class="field-holder">
                                            <label for="phone">phone</label>

                                            <div class="input-holder"><input type="tel" id="phone" name="phone"
                                                                             required></div>
                                        </div>
                                        <div class="field-holder">
                                            <label for="subject">subject</label>

                                            <div class="input-holder"><input type="text" id="subject" name="subject">
                                            </div>
                                        </div>
                                        <div class="field-holder">
                                            <label for="message">message</label>

                                            <div class="input-holder"><textarea id="message" name="message"
                                                                                required></textarea></div>
                                        </div>
                                        <button type="submit">SEND</button>
                                        <?php echo e(Form::close()); ?>

                                    </div>
                                </div>
                                <span class="small-heading">Summary</span>
                                <ul class="sumery-list">
                                    <li>
                                        <span class="tag">Property ID</span>
                                        <span class="quantity"><?php echo e($response['data']['property']->id); ?></span>
                                    </li>

                                    <li>
                                        <span class="tag">Society</span>
                                        <span class="quantity"><?php echo e($response['data']['property']->location->society->name); ?></span>
                                    </li>
                                    <?php if($response['data']['property']->location->block != null && $response['data']['property']->location->block->name != 'other'): ?>
                                        <li>
                                            <span class="tag">Block</span>
                                            <span class="quantity"><?php echo e($response['data']['property']->location->block->name); ?></span>
                                        </li>
                                    <?php endif; ?>

                                    <li>
                                        <span class="tag">Type</span>
                                        <span class="quantity"><?php echo e($response['data']['property']->type->parentType->name); ?></span>
                                    </li>
                                    <li>
                                        <span class="tag blue">Area</span>
                                        <span class="quantity blue"><?php echo e($response['data']['property']->land->area.' '.$response['data']['property']->land->unit->name); ?></span>
                                    </li>
                                    <li>
                                        <span class="tag blue">Price</span>
                                        <span class="quantity blue"><?php echo e(App\Libs\Helpers\PriceHelper::numberToRupees($response['data']['property']->price)); ?></span>
                                    </li>
                                </ul>
                                <div class="layout">
                                    <div class="pull-left">
                                        <span class="timeOfAddedProperty">Property Added
                                            <?php
                                            $startTimeStamp = strtotime(date("Y/m/d"));
                                            $myDate = substr($response['data']['property']->createdAt, 0, 10);
                                            $endTimeStamp = strtotime($myDate);
                                            $timeDiff = abs($endTimeStamp - $startTimeStamp);
                                            $numberDays = $timeDiff / 86400;  // 86400 seconds in one day
                                            // and you might want to convert to integer
                                            $numberDays = intval($numberDays);
                                            $days = "";
                                            if ($numberDays == 0) {
                                                $days = 'today';
                                            } elseif ($numberDays == 1) {
                                                $days = 'day ago';
                                            } else {
                                                $days = 'days ago';
                                            };
                                            ?>
                                            <b><?php if($numberDays !=0): ?><?php echo e($numberDays); ?> <?php endif; ?> <?php echo e($days); ?></b></span>

                                    </div>
                                    <div class="pull-right">
                                        <?php
                                        $heightPriorityFeatures = [];
                                        foreach ($response['data']['property']->features as $section => $features) {
                                            foreach ($features as $feature) {
                                                if ($feature->priority > 0) {
                                                    $heightPriorityFeatures[] = $feature;
                                                }
                                            }
                                        }
                                        ?>
                                        <ul class="public-ui-features text-capital">
                                            <?php foreach($heightPriorityFeatures as $heightPriorityFeature): ?>
                                                <li>
                                                    <span><b><?php echo e($heightPriorityFeature->name); ?></b></span>
                                                    <strong><?php echo e($heightPriorityFeature->value); ?></strong>
                                                </li>
                                            <?php endforeach; ?>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="overview-section">
                            <div class="layout">
                                <span class="small-heading">Property Overview</span>
                                <a href="#" class="btn-hollow"><span class="icon-printer"></span>PRINT DETAILS</a>
                            </div>
                            <p><?php echo e($response['data']['property']->description); ?></p>
                        </div>
                        <?php if($response['data']['property']->features !=null): ?>
                        <div class="extra-feature-section">
                            <div class="extra-feature-holder">

                                    <span class="small-heading">Property Features</span>

                                <div class="feature">
                                    <?php foreach($response['data']['property']->features as $sectionName=>$features): ?>
                                        <span class="small-heading"><?php echo e($sectionName); ?></span>
                                        <ul class="feature-list">
                                            <?php foreach($features as $feature): ?>
                                                <li>
                                                    <span class="text-feature"><span
                                                                class="icon-bed"></span><?php echo e($feature->name); ?></span>
                                                    <?php if($feature->htmlStructure->name =='checkbox'): ?>
                                                        <span class="stataus">yes</span>
                                                    <?php else: ?>
                                                        <span class="stataus"><?php echo e($feature->value); ?></span>
                                                    <?php endif; ?>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.v2.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>