<?php $__env->startSection('content'); ?>
    <div class="page-holder">
     <h1>Property #<?php echo e($response['data']['propertyId']); ?> Not Found </h1>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.v2.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>