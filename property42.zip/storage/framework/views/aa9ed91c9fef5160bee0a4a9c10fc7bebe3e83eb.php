<?php $__env->startSection('content'); ?>
    <?php
    if(\Session::has('validationErrors')){
        $validationErrors = \Session::get('validationErrors');
    }
    ?>
   <main id="main" role="main">
        <div class="page-holder">
            <div class="login-page container">
                <?php if(\Session::has('success')): ?><span class="global-success"><?php echo e(\Session::get('success')); ?></span><?php endif; ?>
                    <?php if(\Session::has('errors')): ?>
                        <span class="global-error"> <?php foreach(\Session::get('errors') as $error): ?> <?php echo e($error); ?><br> <?php endforeach; ?>
                    </span>
                    <?php endif; ?>
                <form class="login-form" action="<?php echo e(route('login')); ?>" method="post">
                    <h1>Log<span>in</span></h1>
                    <div class="layout">
                        <label for="login-email">E-mail ID</label>
                        <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('email')): ?> error <?php endif; ?>">
                            <input name="email" type="email" value="<?php echo e(old('email')); ?>" placeholder="Enter Your Email Address" id="email" required>
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('email')): ?> <?php echo e($validationErrors->first('email')); ?> <?php endif; ?></span>
                        </div>
                    </div>
                    <div class="layout">
                        <label for="login-pass">Password</label>
                        <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('password')): ?> error <?php endif; ?>">
                            <input name="password" type="password" value="<?php echo e(old('password')); ?>" placeholder="Enter Your Password" id="pass" required>
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('password')): ?> <?php echo e($validationErrors->first('password')); ?> <?php endif; ?></span>
                            <a href="#forgot-pass" class="forgot-pass lightbox">Forgot Password ?</a>
                        </div>
                    </div>
                    <ul class="buttons-holder text-upparcase">
                        <li>
                            <a href="<?php echo e(url('/register')); ?>">REGISTER NOW</a>
                        </li>
                        <li>
                            <button type="submit">LOGIN<span class="icon-login"></span></button>
                        </li>
                    </ul>
                </form>
                <div class="popup-holder">
                    <div class="popup lightbox generic-lightbox" id="forgot-pass">
                        <?php echo e(Form::open(array('url' => 'get-new-password','method' => 'POST' ,'class'=>'forgot-form'))); ?>


                            <h1>Forgot <span>Password</span></h1>
                            <p>Enter your email address below and we will send you a new password.</p>
                            <div class="layout">
                                <label for="forgot-email">E-mail ID</label>
                                <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('email')): ?> error <?php endif; ?>">
                                    <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('email')): ?> <?php echo e($validationErrors->first('email')); ?> <?php endif; ?></span>
                                    <input type="email" name="email" placeholder="Enter Your Email Address" id="email">

                                </div>
                            </div>
                            <ul class="buttons-holder text-upparcase text-center">
                                <li>
                                    <button type="submit">SEND</button>
                                </li>
                            </ul>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.v2.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>