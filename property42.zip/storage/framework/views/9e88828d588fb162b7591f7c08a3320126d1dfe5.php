<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="login-registarHolder">
        <?php
        if(\Session::has('validationErrors')){
            $validationErrors = \Session::get('validationErrors');
        }
        ?>
            <ul class="tabset">
                <li class="active"><a  href="<?php echo e(url('/register')); ?>">become a free member</a></li>
                <li class="last-child"><span>Already have an account ?</span> <a href="<?php echo e(url('/login')); ?>">Login</a></li>
            </ul>
        <div class="tab-content">
            <div id="tab2">
                <?php if(\Session::has('success')): ?>
                    <?php echo e(\Session::get('success')); ?>

                <?php endif; ?>
                <?php if(\Session::has('errors')): ?>
                        <span style="color:red;">
                            <?php foreach(\Session::get('errors') as $error): ?>
                                <?php echo e($error); ?><br>
                            <?php endforeach; ?>
                        </span>
                <?php endif; ?>

                <form class="registration-form" method="post" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('fName')): ?> error <?php endif; ?>">
                        <label class="icon-user" for="fName"></label>
                        <input type="text" placeholder="Enter Your First Name" name="fName" id="fName" value="<?php echo e(old('fName')); ?>" required>
                        <span class="border"></span>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('fName')): ?> <?php echo e($validationErrors->first('fName')); ?> <?php endif; ?></span>
                    </div>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('lName')): ?> error <?php endif; ?>">
                        <label class="icon-user" for="lName"></label>
                        <input type="text" placeholder="Enter Your Last Name" name="lName" value="<?php echo e(old('lName')); ?>" id="lName" required>
                        <span class="border"></span>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('lName')): ?> <?php echo e($validationErrors->first('lName')); ?> <?php endif; ?></span>
                    </div>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('password')): ?> error <?php endif; ?>">
                        <label class="icon-key" for="pass1"></label>
                        <input type="password" placeholder="Enter Your Password" id="pass1"  name="password" required>
                        <span class="border"></span>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('password')): ?> <?php echo e($validationErrors->first('password')); ?> <?php endif; ?></span>
                    </div>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('passwordAgain')): ?> error <?php endif; ?>">
                        <label class="icon-key" for="cpass"></label>
                        <input type="password"  placeholder="Confirm Password" name="passwordAgain" id="cpass" required>
                        <span class="border"></span>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('passwordAgain')): ?> <?php echo e($validationErrors->first('passwordAgain')); ?> <?php endif; ?></span>
                    </div>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('email')): ?> error <?php endif; ?>">
                        <label class="icon-envelope" for="email1"></label>
                        <input type="email" placeholder="Enter Your Email Address"  id="email1" value="<?php echo e(old('email')); ?>" name="email" required>
                        <span class="border"></span>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('email')): ?> <?php echo e($validationErrors->first('email')); ?> <?php endif; ?></span>
                    </div>
                    <h1>Contact Information</h1>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('phone')): ?> error <?php endif; ?>">
                        <label class="icon-phone" for="phone"></label>
                        <input type="tel" placeholder="Enter Your Phone Number" name="phone" value="<?php echo e(old('phone')); ?>" id="phone" >
                        <span class="border"></span>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('phone')): ?> <?php echo e($validationErrors->first('phone')); ?> <?php endif; ?></span>
                    </div>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('mobile')): ?> error <?php endif; ?>">
                        <label class="icon-phone_iphone" for="cell"></label>
                        <input type="tel" placeholder="Enter Your Cell / Mobile Number" value="<?php echo e(old('mobile')); ?>" name="mobile" id="cell" required>
                        <span class="border"></span>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('mobile')): ?> <?php echo e($validationErrors->first('mobile')); ?> <?php endif; ?></span>
                    </div>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('fax')): ?> error <?php endif; ?>">
                        <label class="icon-fax" for="fax"></label>
                        <input type="tel" placeholder="Enter Fax Details" value="<?php echo e(old('fax')); ?>" name="fax" id="fax" >
                        <span class="border"></span>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('fax')): ?> <?php echo e($validationErrors->first('fax')); ?> <?php endif; ?></span>
                    </div>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('address')): ?> error <?php endif; ?>">
                        <label class="icon-directions" for="address"></label>
                        <input type="text" placeholder="Enter Your Address" value="<?php echo e(old('address')); ?>" name="address" id="address" >
                        <span class="border"></span>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('address')): ?> <?php echo e($validationErrors->first('address')); ?> <?php endif; ?></span>
                    </div>
                    <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('zipCode')): ?> error <?php endif; ?>">
                        <label class="icon-file-zip" for="zip"></label>
                        <input type="text" placeholder="Enter Zip Code" name="zipCode" value="<?php echo e(old('zipCode')); ?>" id="zip">
                        <span class="border"></span>
                        <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('zipCode')): ?> <?php echo e($validationErrors->first('zipCode')); ?> <?php endif; ?></span>
                    </div>
                    <div class="input-holder">
                        <label for="agent" class="agent-check">
                            <input type="checkbox" class="hidden-checkfield agent-brokerCheckbox" name="agent" <?php if(old('agent') !=""): ?>checked <?php endif; ?>  id="agent">
										<span class="fake-checkbox">
											<span class="fake-button"></span>
										</span>
                            <span class="fake-label">Are you an Agent</span>
                        </label>
                    </div>
                    <div class="input-holder full-width <?php if(isset($validationErrors) && $validationErrors->has('userRoles')): ?> error <?php endif; ?>">
                        <div class="roles">
                            <a class="role-opener">Other Roles:</a>
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('userRoles')): ?> <?php echo e($validationErrors->first('userRoles')); ?> <?php endif; ?></span>
                            <ul class="role-listing">
                                <?php foreach($response['roles'] as $role): ?>
                                    <li>
                                        <input type="checkbox" id="role_<?php echo e($role->id); ?>" class="userRole-checkbox <?php if($role->id == 3): ?> agent-brokerCheckbox <?php endif; ?>;" name="userRoles[]" value="<?php echo e($role->id); ?>" <?php if(in_array($role->id,(old('userRoles') !=null)?old('userRoles'):[])): ?> checked <?php endif; ?>>
                                        <label for="role_<?php echo e($role->id); ?>"><?php echo e($role->name); ?></label>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                    <div class="agent-information">
                        <h1>Agency Information</h1>
                        <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('agencyName')): ?> error <?php endif; ?>">
                            <label for="agency-name" class="icon-agency"></label>
                            <input type="text" placeholder="Enter An Agency Name" id="agency-name" name="agencyName" value="<?php echo e(old('agencyName')); ?>" >
                            <span class="border"></span>
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('agencyName')): ?> <?php echo e($validationErrors->first('agencyName')); ?> <?php endif; ?></span>
                        </div>
                        <div class="input-holder onTop-mobile <?php if(isset($validationErrors) && $validationErrors->has('companyLogo')): ?> error <?php endif; ?>">
                            <div class="company-logo">
                                <input type="file" name="companyLogo"  onchange="companyLogoUploader(this , '.company-profileP')">
                                <div class="picture-holder"><img src="" class="company-profileP" alt="Company logo"></div>
                                <a class="delete"><span class="icon-bin"></span></a>
                                <span class="name-tag">Add Company Logo</span>
                            </div>
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('companyLogo')): ?> <?php echo e($validationErrors->first('companyLogo')); ?> <?php endif; ?></span>
                        </div>
                        <div class="input-holder full-width <?php if(isset($validationErrors) && $validationErrors->has('agencyDescription')): ?> error <?php endif; ?>">
                            <label for="D-services" class="icon-technical-support"></label>
                            <textarea id="D-services" name="agencyDescription" placeholder="Description of Services"><?php echo e(old('agencyDescription')); ?></textarea>
                            <span class="border"></span>
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('agencyDescription')): ?> <?php echo e($validationErrors->first('agencyDescription')); ?> <?php endif; ?></span>
                        </div>
                        <div class="input-holder full-width no-indent  <?php if(isset($validationErrors) && $validationErrors->has('societies')): ?> error <?php endif; ?>">
                            <label for="search-society" class="icon-society"></label>
                            <input type="text" placeholder="Select Societies You Deal In:" id="search-society" name="SelectDealSociety">
                            <span class="border"></span>
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('societies')): ?> <?php echo e($validationErrors->first('societies')); ?> <?php endif; ?></span>
                            <span class="calculatedSocieties"></span>
                        </div>

                        <div class="input-holder full-width">
                            <ul class="societiesBlock-listing">
                                <?php foreach($response['societies'] as $society): ?>
                                    <li>
                                        <input type="checkbox" id="society<?php echo e($society->id); ?>" class="selectSociety-checkbox" name="societies[]" value="<?php echo e($society->id); ?>"
                                               <?php if(in_array($society->id,(old('societies') !=null)?old('societies'):[])): ?> checked <?php endif; ?>>
                                        <label for="society<?php echo e($society->id); ?>"><?php echo e($society->name); ?></label>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <h1> Agency Contact Details</h1>
                        <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('companyPhone')): ?> error <?php endif; ?>">
                            <label for="compny-phone" class="icon-phone"></label>
                            <input type="tel" placeholder="Enter Company Phone Number" name="companyPhone" value="<?php echo e(old('companyPhone')); ?>" id="compny-phone" >
                            <span class="border"></span>
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('companyPhone')): ?> <?php echo e($validationErrors->first('companyPhone')); ?> <?php endif; ?></span>
                        </div>
                        <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('companyMobile')): ?> error <?php endif; ?>">
                            <label for="compny-mobile" class="icon-phone_iphone"></label>
                            <input type="tel" placeholder="Enter Company Mobile Number" name="companyMobile" value="<?php echo e(old('companyMobile')); ?>" id="compny-mobile" >
                            <span class="border"></span>
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('companyMobile')): ?> <?php echo e($validationErrors->first('companyMobile')); ?> <?php endif; ?></span>
                        </div>
                        <div class="input-holder full-width <?php if(isset($validationErrors) && $validationErrors->has('companyAddress')): ?> error <?php endif; ?>">
                            <label for="compny-address" class="icon-directions"></label>
                            <input type="text" placeholder="Enter Company Address" name="companyAddress" value="<?php echo e(old('companyAddress')); ?>" id="compny-address" >
                            <span class="border"></span>
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('companyAddress')): ?> <?php echo e($validationErrors->first('companyAddress')); ?> <?php endif; ?></span>
                        </div>
                        <div class="input-holder <?php if(isset($validationErrors) && $validationErrors->has('companyEmail')): ?> error <?php endif; ?>">
                            <label for="compny-email" class="icon-envelope"></label>
                            <input type="email" placeholder="Enter Company Email" name="companyEmail" value="<?php echo e(old('companyEmail')); ?>" id="compny-email" >
                            <span class="border"></span>
                            <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('companyEmail')): ?> <?php echo e($validationErrors->first('companyEmail')); ?> <?php endif; ?></span>
                        </div>
                    </div>
                    <div class="input-holder full-width <?php if(isset($validationErrors) && $validationErrors->has('termsConditions')): ?> error <?php endif; ?>">
                        <ul class="terms-listing">
                            <li>
                                <input type="checkbox" id="terms-Cond" name="termsConditions" value="1" <?php if(old('termsConditions') !=""): ?>checked <?php endif; ?> required>
                                <label for="terms-Cond">I have read and agree to Property42.pk <a href="#">Terms and Conditions</a> <span class="error-text"><?php if(isset($validationErrors) && $validationErrors->has('termsConditions')): ?> <?php echo e($validationErrors->first('termsConditions')); ?> <?php endif; ?></span></label>
                            </li>
                            <li>
                                <input type="checkbox" id="newslatter" name="wantNotifications" <?php if(old('wantNotifications') !=""): ?>checked <?php endif; ?> >
                                <label for="newslatter">I  want to receive notifications for promotions, newsletters and website updates.</label>
                            </li>
                        </ul>
                    </div>
                    <div class="input-holder full-width">
                        <button type="submit">Sign me up !!</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
    <script>
        $(document).ready(function(){
            $( ".hidden-checkfield" ).trigger( "change" );
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>