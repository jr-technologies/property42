<h1>Society Name : <?php echo e($response['data']['societiesMaps'][0]->society); ?></h1>
<?php foreach($response['data']['societiesMaps'] as $society): ?>
<img src="<?php echo e(url('/').$society->path); ?>" width="100" height="100">
<?php endforeach; ?>