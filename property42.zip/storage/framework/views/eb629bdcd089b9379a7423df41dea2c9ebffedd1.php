<h1>Property42</h1>
<b><?php echo e($user['from']); ?></b><br />
<b><?php echo e($user['message']); ?></b><br />
