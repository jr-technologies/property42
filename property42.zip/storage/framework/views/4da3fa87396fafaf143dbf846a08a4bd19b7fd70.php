<?php $__env->startSection('content'); ?>
    <div class="page-holder">
        <div class="listing-page">
            <div class="container">
                <a class="aside-opener-filters">Search Filters (Land, Area, ...)<span class="button"><b></b></span></a>
                <aside id="aside" class="hideOnMobile">
                    <form class="filter-form" id="properties-filter-form" method="get" action="<?= url('/search') ?>">
                        <ul class="filters-links text-upparcase">
                            <li class="active">
                                <a class="filters-links-opener">LAND AREA</a>
                                <div class="slide">
											<span class="fake-select">
												<select name="land_unit_id" class="filter-form-input">
                                                    <?php foreach($response['data']['landUnits'] as $landUnit): ?>
                                                        <option value="<?php echo e($landUnit->id); ?>"
                                                                <?php if($response['data']['oldValues']['landUnitId'] == $landUnit->id): ?> selected
                                                                <?php elseif($response['data']['oldValues']['landUnitId'] == "" && $landUnit->id == 3): ?> selected <?php endif; ?>><?php echo e($landUnit->name); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
											</span>
                                    <div class="fromTo">
                                        <div class="field-holder">
                                            <input type="number" placeholder="From"  name="land_area_from" value="<?php echo e($response['data']['oldValues']['landAreaFrom']); ?>">
                                        </div>
                                        <div class="field-holder">
                                            <input type="number" placeholder="To" name="land_area_to" value="<?php echo e($response['data']['oldValues']['landAreaTo']); ?>">
                                        </div>
                                        <button type="submit">Go</button>
                                    </div>
                                </div>
                            </li>
                            <li class="active">
                                <a class="filters-links-opener">PRICE RANGE</a>
                                <div class="slide">
                                    <div class="fromTo">
                                        <div class="field-holder">
                                            <input type="number" placeholder="From" name="price_from" value="<?php echo e($response['data']['oldValues']['priceFrom']); ?>" class="priceInputFrom PriceField">
                                        </div>
                                        <div class="field-holder">
                                            <input type="number" placeholder="To"  name="price_to"value="<?php echo e($response['data']['oldValues']['priceTo']); ?>" class="priceInputTo PriceField">
                                        </div>
                                        <button type="submit">Go</button>
                                    </div>
                                    <span class="calculatedPrice">Please enter the price.</span>
                                </div>
                            </li>
                            <li class="active">
                                <a class="filters-links-opener">PROPERTY FOR</a>
                                <div class="slide">
                                    <ul class="filterChecks">
                                        <li>
                                            <label for="buy-filter" class="customRadio">
                                                <input type="radio" name="purpose_id" id="buy-filter" class="filter-form-input" value="1" <?php if($response['data']['oldValues']['purposeId'] == 1): ?> checked <?php endif; ?>>
                                                <span class="fake-checkbox"></span>
                                                <span class="fake-label">BUY</span>
                                            </label>
                                        </li>
                                        <li>
                                            <label for="rent-filter" class="customRadio">
                                                <input type="radio" name="purpose_id" id="rent-filter" class="filter-form-input" value="2" <?php if($response['data']['oldValues']['purposeId'] == 2): ?> checked <?php endif; ?>>
                                                <span class="fake-checkbox"></span>
                                                <span class="fake-label">Rent</span>
                                            </label>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="active">
                                <a class="filters-links-opener">Property Type</a>
                                <div class="slide">
                                    <ul class="filterChecks">
                                        <li>
                                            <label for="all-types" class="customRadio">
                                                <input type="radio" id="all-types"
                                                       <?php if($response['data']['oldValues']['propertyTypeId'] == ""): ?> checked <?php endif; ?>
                                                       name="property_type_id" class="property_type filter-form-input" value="">
                                                <span class="fake-checkbox"></span>
                                                <span class="fake-label">All Types</span>
                                            </label>
                                        </li>
                                        <?php foreach($response['data']['propertyTypes'] as $propertyType): ?>
                                            <li>
                                                <label for="<?php echo e($propertyType->name."_".$propertyType->id); ?>" class="customRadio">
                                                    <input type="radio" id="<?php echo e($propertyType->name."_".$propertyType->id); ?>"
                                                           <?php if($response['data']['oldValues']['propertyTypeId'] == $propertyType->id): ?>checked <?php endif; ?>
                                                           name="property_type_id" class="property_type filter-form-input" value="<?php echo e($propertyType->id); ?>">
                                                    <span class="fake-checkbox"></span>
                                                    <span class="fake-label"><?php echo e($propertyType->name); ?></span>
                                                </label>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </li>
                            <li class="active">
                                <a class="filters-links-opener">Property SUB-Type</a>
                                <div class="slide">
                                    <ul class="filterChecks">
                                        <li>
                                            <label for="all-sub-types" class="customRadio">
                                                <input type="radio" id="all-sub-types"
                                                       <?php if($response['data']['oldValues']['subTypeId'] == ""): ?> checked <?php endif; ?>
                                                       name="sub_type_id" class="property_sub_type filter-form-input" value="">
                                                <span class="fake-checkbox"></span>
                                                <span class="fake-label">All Sub Types</span>
                                            </label>
                                        </li>
                                        <?php foreach($response['data']['propertySubtypes'] as $propertySubType): ?>
                                            <li>
                                                <label for="<?php echo e($propertySubType->name."_".$propertySubType->id); ?>" class="customRadio">
                                                    <input type="radio" id="<?php echo e($propertySubType->name."_".$propertySubType->id); ?>"
                                                           <?php if($response['data']['oldValues']['subTypeId'] == $propertySubType->id): ?> checked <?php endif; ?>
                                                           name="sub_type_id" class="property_sub_type filter-form-input" value="<?php echo e($propertySubType->id); ?>">
                                                    <span class="fake-checkbox"></span>
                                                    <span class="fake-label"><?php echo e($propertySubType->name); ?></span>
                                                </label>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </li>
                            <li class="active">
                                <a class="filters-links-opener">LOCATION / SOCITY</a>
                                <div class="slide">
                                    <ul class="filterChecks">
                                        <li>
                                            <select class="js-example-basic-single filter-form-input" name="society_id">
                                                <option  value="">All Societies</option>
                                                <?php foreach($response['data']['societies'] as $society): ?>
                                                    <option value="<?php echo e($society->id); ?>" <?php if($response['data']['oldValues']['societyId'] == $society->id): ?> selected <?php endif; ?>><?php echo e($society->name); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </li>
                                        <li>
                                            <select class="js-example-basic-single filter-form-input " <?php if(sizeof($response['data']['blocks']) == 0): ?> disabled <?php endif; ?> name="block_id">
                                                <option  value="">All Blocks</option>
                                                <?php foreach($response['data']['blocks'] as $block): ?>
                                                    <option value="<?php echo e($block->id); ?>" <?php if($response['data']['oldValues']['blockId'] == $block->id): ?> selected <?php endif; ?>><?php echo e($block->name); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </form>
                </aside>
                <section id="content">
                    <?php foreach($response['data']['properties'] as $property): ?>
                        <?php
                        $image = url('/')."/assets/imgs/no.png";
                        foreach($property->documents as $document)
                        {
                            if($document->type == 'image' && $document->main == true)
                            {
                                $image = url('/').'/temp/'.$document->path;
                            }
                        }
                        ?>
                        <article class="publicProperty-post">
                            <div class="image-holder">
                                <a href="property?propertyId=<?php echo e($property->id); ?>"><img src="<?php echo e($image); ?>" alt="image description"></a>
                                <a href="#" class="add-to-favorite"></a>
                                <span class="premiumProperty text-upparcase"><?php if($property->isFeatured !=null): ?><?php echo e('Featured'); ?><?php endif; ?></span>
                            </div>
                            <div class="caption text-left">
                                <div class="layout">
                                    <div class="left-area">
                                        <h1><a href="property?propertyId=<?php echo e($property->id); ?>"><?php echo e(''.$property->land->area.' '.$property->land->unit->name .' '); ?><?php echo e($property->type->subType->name.'
                                             '.$property->purpose->name.' in '.$property->location->block->name.' Block'.
                                             ' '.$property->location->society->name); ?></a></h1>
                                        <p><?php echo e(str_limit($property->description,170)); ?></p>
                                    </div>
                                    <div class="right-area">
                                        <strong class="price"><span>Rs</span> <?php echo e(App\Libs\Helpers\PriceHelper::numberToRupees($property->price)); ?></strong>
                                        <ul class="public-ui-features text-capital">
                                            <?php foreach($property->features as $feature): ?>
                                                <?php foreach($feature as $featureSection): ?>
                                                    <?php if($featureSection->priority ==1): ?>
                                                        <li>
                                                            <span><b><?php echo e($featureSection->name); ?></b><span <?php echo e(($featureSection->name == 'bedrooms')?'class="icon-bed':'class="icon-bath'); ?>></span></span>
                                                            <strong><?php echo e($featureSection->value); ?></strong>
                                                        </li>
                                                    <?php endif; ?>
                                                <?php endforeach; ?>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>
                                </div>
                                <div class="layout">
                                    <div class="links-left">
                                        <a href="property?propertyId=<?php echo e($property->id); ?>" class="btn-default text-upparcase">VIEW DETAILS <span class="icon-Vector-Smart-Object"></span></a>
                                        <?php if(isset($property->isVerified) && $property->isVerified == 1): ?>
                                            <span class="trusted-agent"><span class="icon-trusted"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span><span class="path7"></span><span class="path8"></span></span>Verified</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="links-right">
                                        <ul class="quick-links">
                                            <li><a href="#callPopup" class="lightbox call-agent-btn" data-tel="<?php echo e($property->phone); ?>"><span class="icon-phone"></span></a></li>
                                            <li><a href="#sendEmail-popup" class="lightbox"><span class="icon-empty-envelop"></span></a></li>
                                        </ul>
                                        <?php
                                        $image = url('/') . "/assets/imgs/no.png";
                                        if ($property->owner->agency != null) {
                                            if ($property->owner->agency->logo != null) {
                                                $image = url('/') . '/temp/' . $property->owner->agency->logo;
                                            }
                                        }
                                        ?>
                                        <a href="<?php echo e(URL::to('agent?agent_id='.$property->owner->id)); ?>"> <img src="<?php echo e($image); ?>" alt="image description" class="company-logo"></a>
                                    </div>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </section>
                <?php
                $for_previous_link = $_GET;
                $pageValue = (isset($for_previous_link['page']))?$for_previous_link['page']:1;
                ($pageValue ==1)?$for_previous_link['page'] = $pageValue:$for_previous_link['page'] = $pageValue-1;
                $convertPreviousToQueryString  = http_build_query($for_previous_link);
                $previousResult = URL('/search').'?'.$convertPreviousToQueryString;
                ?>
                <?php
                $totalPaginationValue = intval(ceil($response['data']['totalProperties'] / config('constants.Pagination')));
                $for_next_link = $_GET;
                $pageValue = (isset($for_next_link['page']))?$for_next_link['page']:1;
                ($pageValue == $totalPaginationValue)?$for_next_link['page'] = $pageValue:$for_next_link['page'] = $pageValue+1;
                $convertToQueryString  = http_build_query($for_next_link);
                $nextResult = URL('/search').'?'.$convertToQueryString;
                ?>
                <ul class="pager">
                    <?php if($totalPaginationValue !=0): ?>
                        <li><a href="<?php echo e($previousResult); ?>" class="previous"><span class="icon-chevron-thin-left"></span></a></li>
                    <?php endif; ?>
                    <?php
                    $paginationValue = intval(ceil($response['data']['totalProperties'] / config('constants.Pagination')));
                    $query_str_to_array = $_GET;
                    $current_page = (isset($query_str_to_array['page']))?$query_str_to_array['page']:1;
                    for($i = (($current_page-3 > 0)?$current_page-3:1); $i <= (($current_page + 3 <= $paginationValue)?$current_page+3:$paginationValue);$i++){
                    $query_str_to_array['page'] = $i;
                    $queryString  = http_build_query($query_str_to_array);
                    $result = URL('/search').'?'.$queryString;
                    ?>
                    <li <?php if($current_page == $i): ?>class="active" <?php endif; ?>><a href="<?php echo e($result); ?>"><?php echo e($i); ?></a></li>
                    <?php }?>
                    <?php if($totalPaginationValue !=0): ?>
                        <li><a href="<?php echo e($nextResult); ?>" class="next"><span class="icon-chevron-thin-right"></span></a></li>
                    <?php endif; ?>
                </ul>
                <div class="popup-holder">
                    <div id="callPopup" class="lightbox call-agent">
                        <p></p>
                    </div>
                    <div id="sendEmail-popup" class="lightbox">
                        <form class="inquiry-email-form">
                            <div class="field-holder">
                                <label for="name">Name</label>
                                <div class="input-holder"><input type="text" id="name"></div>
                            </div>
                            <div class="field-holder">
                                <label for="email">Email</label>
                                <div class="input-holder"><input type="email" id="email"></div>
                            </div>
                            <div class="field-holder">
                                <label for="phone">phone</label>
                                <div class="input-holder"><input type="tel" id="phone"></div>
                            </div>
                            <div class="field-holder">
                                <label for="subject">subject</label>
                                <div class="input-holder"><input type="text" id="subject"></div>
                            </div>
                            <div class="field-holder">
                                <label for="message">message</label>
                                <div class="input-holder"><textarea id="message"></textarea></div>
                            </div>
                            <button type="submit">SEND</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.v2.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>