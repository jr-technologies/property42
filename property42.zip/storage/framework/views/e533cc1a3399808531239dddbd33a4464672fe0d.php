<?php foreach($response['data']['societiesForFiles'] as $society): ?>
<a href="<?php echo e(URL::to('get/society/files?societyId=').$society->id); ?>"><h1><?php echo e($society->name); ?></h1></a>
<?php endforeach; ?>