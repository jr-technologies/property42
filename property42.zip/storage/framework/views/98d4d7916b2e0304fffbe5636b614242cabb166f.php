<h1>Property42</h1>
<h1>This is you new Password</h1>
<b><?php echo e($password); ?></b><br />
