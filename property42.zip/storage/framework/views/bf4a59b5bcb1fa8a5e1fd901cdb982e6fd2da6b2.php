
<?php $__env->startSection('content'); ?>
    <div id="content">
        <div class="container">
            <div class="page-holder">
                <div class="agentProfile-page">
                    <div class="layout">
                        <div class="main-infoHolder">
                            <div class="img-holder">
                                <?php
                                $image = url('/') . "/assets/imgs/no.png";
                                if ($response['data']['agent']->agencies[0]->logo != "") {
                                    $image = url('/') . '/temp/' . $response['data']['agent']->agencies[0]->logo;
                                }
                                ?>
                                <img
                                        src="<?php echo e($image); ?>"
                                        width="300" height="300" alt="image description"></div>
                            <div class="cap-name">
                                <strong class="name"><?php echo e($response['data']['agent']->agencies[0]->name); ?></strong>

                                <p><?php echo e($response['data']['agent']->agencies[0]->description); ?></p>
                            </div>
                        </div>
                        <ul class="contact-links">
                            <li >
                                <a class="lightbox" href="#send-emailForm"><span
                                            class="icon-envelope"></span>Send Email</a>
                                <div class="popup-holder">
                                    <?php if(\Session::has('validationErrors')): ?>
                                        <?php $errors = \Session::get('validationErrors');?>
                                    <?php endif; ?>
                                    <div class="lightbox" id="send-emailForm">
                                        <strong class="form-heading">Send Email</strong>

                                        <?php echo e(Form::open(array('url' => 'agent/mail','method' => 'GET', 'class'=>'enquiry-form'))); ?>

                                        <ul>
                                            <input type="hidden" id="name" name="to"
                                                   value="<?php echo e($response['data']['agent']->email); ?>">
                                            <li>
                                                <label for="name">Name</label>

                                                <div class="input-holder <?php if($errors->has('name')): ?> error <?php endif; ?>">
                                                    <input type="text" id="name" name="name" required
                                                           placeholder="Please enter your Name" value="<?php echo e(old('name')); ?>">
                                                    <span class="error-text"><?php if($errors->has('name')): ?> <?php echo e($errors->first('name')); ?> <?php endif; ?></span>
                                                </div>
                                            </li>
                                            <li>
                                                <label for="email">Email</label>

                                                <div class="input-holder <?php if($errors->has('email')): ?> error <?php endif; ?>">
                                                    <input type="text" id="email" name="email" required
                                                           placeholder="Please enter your Email" value="<?php echo e(old('email')); ?>">
                                                    <span class="error-text"><?php if($errors->has('email')): ?> <?php echo e($errors->first('email')); ?> <?php endif; ?></span>
                                                </div>
                                            </li>

                                            <li>
                                                <label for="cell">Cell</label>

                                                <div class="input-holder <?php if($errors->has('cell')): ?> error <?php endif; ?>">
                                                    <input type="tel" id="cell" name="cell" required
                                                           placeholder="Please enter your Cell" value="<?php echo e(old('cell')); ?>">
                                                    <span class="error-text"><?php if($errors->has('cell')): ?> <?php echo e($errors->first('cell')); ?> <?php endif; ?></span>
                                                </div>
                                            </li>
                                            <li>
                                                <label for="msg">Message</label>

                                                <div class="input-holder <?php if($errors->has('message')): ?> error <?php endif; ?>">
                                            <textarea id="msg" name="message" required
                                                      placeholder="Please enter your Message"><?php echo e(old('message')); ?></textarea>
                                                    <span class="error-text"><?php if($errors->has('message')): ?> <?php echo e($errors->first('message')); ?> <?php endif; ?></span>
                                                </div>
                                            </li>

                                            <li><span>Before submiting this form i agree the <a href="#">Terms and condition</a></span>
                                            </li>
                                        </ul>
                                        <button type="submit"><span class="icon-envelope"></span>Send email</button>
                                        <?php echo e(Form::close()); ?>

                                        </div>
                                    </div>
                            </li>
                            <li><a href="tel:<?php echo e($response['data']['agent']->agencies[0]->phone); ?>"><span
                                            class="icon-phone_iphone"></span><span
                                            class="hidden-xs"><?php echo e($response['data']['agent']->agencies[0]->phone); ?></span><span
                                            class="show-xs">Call Now</span></a></li>
                        </ul>
                    </div>
                    <div class="cols-holder">
                        <div class="col">
                            <header>Agent Information</header>
                            <div class="caption">

                                <strong class="name"><?php echo e($response['data']['agent']->fName.' '.$response['data']['agent']->lName); ?></strong>

                                <p><?php echo e($response['data']['agent']->agencies[0]->description); ?>.</p>
                            </div>
                        </div>
                        <div class="col">
                            <header>Contact Details</header>
                            <div class="caption">
                                <strong class="name"><?php echo e($response['data']['agent']->fName.' '.$response['data']['agent']->lName); ?></strong>
                                <span class="agency-name"><?php echo e($response['data']['agent']->agencies[0]->name); ?></span>
                                <span class="contact-num"><a href="tel:92515400336-39"><span
                                                class="icon-phone"></span><?php echo e($response['data']['agent']->phone); ?>

                                    </a></span>
                                <span class="contact-num"><a href="tel:923018501111"><span
                                                class="icon-phone_iphone"></span><?php echo e($response['data']['agent']->mobile); ?>

                                    </a></span>
                                <address><?php echo e($response['data']['agent']->agencies[0]->address); ?></address>
                            </div>

                        </div>


                        <div class="col">
                            <?php if(sizeof($response['data']['agent']->agencies) > 0 ): ?>
                                <?php if(sizeof($response['data']['agent']->agencies[0]->societies) > 0): ?>
                                    <header>Society he deal in</header>
                                    <div class="caption">
                                        <ul>
                                            <?php foreach($response['data']['agent']->agencies[0]->societies as $society ): ?>
                                                <li><span><?php echo e($society->name); ?></span></li>
                                            <?php endforeach; ?>
                                        </ul>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>