<?php foreach($response['data']['societies'] as $society): ?>
<a href="<?php echo e(URL::to('society/maps?societyId=').$society->id); ?>"><h1><?php echo e($society->name); ?></h1></a>
<?php endforeach; ?>