
<?php $__env->startSection('content'); ?>
    <div id="content">
       <div class="container">
            <div class="page-holder">
                <div class="agentListing-page">
                    <div class="holder">
                        <?php echo e(Form::open(array('url' => 'agents','method' => 'GET','class'=>'search-agent'))); ?>

                            <div class="input-holder">
                                <select  name="society" class="js-example-basic-single">
                                    <option selected disabled>Search by society</option>
                                    <option value="" <?php if($response['data']['params']['society'] == ""): ?> selected <?php endif; ?>>All Societies</option>
                                    <?php foreach($response['data']['societies'] as $society): ?>
                                    <option value="<?php echo e($society->id); ?>" <?php if($response['data']['params']['society'] == $society->id): ?> selected <?php endif; ?>><?php echo e($society->name); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="input-holder">
                                <select  name="agency_name" class="js-example-basic-single">
                                    <option selected disabled>Search by Agents</option>
                                    <option value="" <?php if($response['data']['params']['agencyName'] == ""): ?> selected <?php endif; ?>>All Agent</option>
                                    <?php foreach($response['data']['allAgents'] as $agent): ?>
                                        <option value="<?php echo e($agent->agencies[0]->name); ?>" <?php if($response['data']['params']['agencyName'] == $agent->agencies[0]->name): ?> selected <?php endif; ?>><?php echo e($agent->agencies[0]->name); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                    <input type="submit" value="Search Agent">
                            <?php echo e(Form::close()); ?>

                    </div>
                </div>


                    <section class="property-posts">
                        <?php foreach($response['data']['agents'] as $agent): ?>
                            <?php
                            $image = url('/')."/assets/imgs/no.png";
                            foreach($agent->agencies as $agency)
                            {
                                if($agency->logo !="")
                                {
                                    $image = url('/').'/temp/'.$agency->logo;
                                }
                            }
                            ?>
                            <article class="post">
                                <div class="post-holder">
                                    <div class="img-holder">
                                        <a href="<?php echo e(URL::to('agent?agent_id='.$agent->id)); ?>">
                                            <img src="<?php echo e($image); ?>" width="300" height="300" alt="image description">
                                        </a>
                                    </div>
                                    <div class="caption">
                                        <strong class="post-heading"><a href="<?php echo e(URL::to('agent?agent_id='.$agent->id)); ?>"><?php echo e($agent->agencies[0]->name); ?></a></strong>
                                        <p><?php echo e(str_limit($agent->agencies[0]->description,150)); ?></p>
                                        <div class="holder">
                                            <ul class="quick-links">
                                                <li><a href="tel:<?php echo e($agent->agencies[0]->phone); ?>"><span class="icon-phone_iphone"></span><span class="hidden-xs"><?php echo e($agent->agencies[0]->phone); ?></span><span class="show-xs">Call Now</span></a></li>
                                                <li><a href="<?php echo e(URL::to('agent?agent_id='.$agent->id)); ?>"><span class="icon-pencil"></span>View Details</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </section>
                    <?php
                    $for_previous_link = $_GET;
                    $pageValue = (isset($for_previous_link['page']))?$for_previous_link['page']:1;
                    ($pageValue ==1)?$for_previous_link['page'] = $pageValue:$for_previous_link['page'] = $pageValue-1;
                    $convertPreviousToQueryString  = http_build_query($for_previous_link);
                    $previousResult = URL('/agents').'?'.$convertPreviousToQueryString;
                    ?>
                    <?php
                    $totalPaginationValue = intval(ceil($response['data']['totalAgentsFound'] / config('constants.Pagination')));
                    $for_next_link = $_GET;
                    $pageValue = (isset($for_next_link['page']))?$for_next_link['page']:1;
                    ($pageValue == $totalPaginationValue)?$for_next_link['page'] = $pageValue:$for_next_link['page'] = $pageValue+1;
                    $convertToQueryString  = http_build_query($for_next_link);
                    $nextResult = URL('/agents').'?'.$convertToQueryString;
                    ?>
                    <ul class="pager">
                        <?php
                        $totalPaginationValue = intval(ceil($response['data']['totalAgentsFound'] / config('constants.Pagination')));
                        $for_first_link = $_GET;
                        $current_page = (isset($for_first_link['page'])) ? $for_first_link['page']: 1;
                        $for_first_link['page']=1;
                        $convertFirstRecordToQueryString  = http_build_query($for_first_link);
                        $firstResult = URL('/agents').'?'.$convertFirstRecordToQueryString;
                        ?>
                        <?php if($current_page >=5): ?>
                            <a href="<?php echo e($firstResult); ?>">First</a>
                         <?php endif; ?>
                        <li><a href="<?php echo e($previousResult); ?>" class="previous"><span class="icon-chevron-thin-left"></span></a></li>
                        <?php
                        $paginationValue = intval(ceil($response['data']['totalAgentsFound'] / config('constants.Pagination')));
                        $query_str_to_array = $_GET;
                        $current_page = (isset($query_str_to_array['page'])) ? $query_str_to_array['page'] : 1;
                        for($i = (($current_page-3 > 0)?$current_page-3:1); $i <= (($current_page + 3 <= $paginationValue)?$current_page+3:$paginationValue);$i++){
                        $query_str_to_array['page'] = $i;
                        $queryString = http_build_query($query_str_to_array);
                        $result = URL('/agents') . '?' . $queryString;
                        ?>
                        <li <?php if($current_page == $i): ?>class="active" <?php endif; ?>><a href="<?php echo e($result); ?>"><?php echo e($i); ?></a></li>
                        <?php }?>
                        <li><a href="<?php echo e($nextResult); ?>" class="next"><span class="icon-chevron-thin-right"></span></a></li>
                        <?php
                        $totalPaginationValue = intval(ceil($response['data']['totalAgentsFound'] / config('constants.Pagination')));
                        $for_last_link = $_GET;
                        $current_page = (isset($for_last_link['page'])) ? $for_last_link['page']: $totalPaginationValue;
                        $for_last_link['page']=$totalPaginationValue;
                        $convertLastRecordToQueryString  = http_build_query($for_last_link);
                        $lastResult = URL('/agents').'?'.$convertLastRecordToQueryString;
                        ?>
                        <?php if($current_page <=$paginationValue-4): ?>
                        <a href="<?php echo e($lastResult); ?>">Last</a>
                        <?php endif; ?>
                    </ul>
            </div>

    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>