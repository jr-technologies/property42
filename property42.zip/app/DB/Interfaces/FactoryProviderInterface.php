<?php
/**
 * Created by PhpStorm.
 * User: zeenomlabs
 * Date: 4/1/2016
 * Time: 9:40 PM
 */

namespace App\DB\Interfaces;


interface FactoryProviderInterface {

} 