<?php
/**
 * Created by PhpStorm.
 * User: WAQAS
 * Date: 5/17/2016
 * Time: 11:07 AM
 */

namespace App\DB\Providers\SQL\Models\Features;


class FeaturesJson
{
    public $id ="";
    public $name = "";
    public $priority = "";
    public $features = [];
}