<?php
/**
 * Created by PhpStorm.
 * User: WAQAS
 * Date: 5/23/2016
 * Time: 12:13 PM
 */

namespace App\DB\Providers\SQL\Models\Property;


class CountPropertiesModel
{
    public $forSale = null;
    public $forRent = null;
}