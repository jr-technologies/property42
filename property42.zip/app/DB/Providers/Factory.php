<?php
/**
 * Created by PhpStorm.
 * User: zeenomlabs
 * Date: 4/2/2016
 * Time: 5:57 PM
 */

namespace App\DB\Providers;


abstract class Factory {

} 