<?php
/**
 * Created by PhpStorm.
 * User: zeenomlabs
 * Date: 3/31/2016
 * Time: 11:00 PM
 */

namespace App\Collections\Collections;


use App\Collections\Interfaces\CollectionInterface;

class UserCollection extends AppCollection implements CollectionInterface {
    public function sortByUpdatedDate()
    {
        //sample method
    }
} 