<?php
/**
 * Created by PhpStorm.
 * User: waqas
 * Date: 3/25/2016
 * Time: 11:44 AM
 */

namespace App\Libs\Json\Prototypes\Interfaces;


interface JsonPrototypeInterface
{

}