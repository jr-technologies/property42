<?php
/**
 * Created by PhpStorm.
 * User: WAQAS
 * Date: 5/17/2016
 * Time: 11:32 AM
 */

namespace App\Libs\Json\Creators\Creators\Feature;


class   SectionsFeaturesJsonPrototype
{

}