<?php
/**
 * Created by PhpStorm.
 * User: waqas
 * Date: 3/16/2016
 * Time: 9:55 AM
 */

namespace App\Libs\Auth;


interface AuthInterface
{
    public function authenticate();
}