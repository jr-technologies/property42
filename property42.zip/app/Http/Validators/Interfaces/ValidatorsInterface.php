<?php

namespace App\Http\Validators\Interfaces;

/**
 * Created by PhpStorm.
 * User: waqas
 * Date: 3/21/2016
 * Time: 9:26 AM
 */
interface ValidatorsInterface
{

}