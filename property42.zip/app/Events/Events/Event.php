<?php

namespace App\Events\Events;

abstract class Event
{
    //
}
