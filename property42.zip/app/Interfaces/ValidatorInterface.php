<?php
/**
 * Created by PhpStorm.
 * User: zeenomlabs
 * Date: 3/15/2016
 * Time: 9:23 PM
 */

namespace App\Interfaces;


interface Validator {

} 